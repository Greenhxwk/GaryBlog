set FLASK_APP=microblog.py
flask run